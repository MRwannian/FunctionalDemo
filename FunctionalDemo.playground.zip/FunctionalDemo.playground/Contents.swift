import UIKit



//MARK: -
//按需求画图--代码如下---
let bounds = CGRect(origin: .zero, size: CGSize(width: 300, height: 200))
let renderer = UIGraphicsImageRenderer(bounds: bounds)
renderer.image { context in
    UIColor.blue.setFill()
    context.fill(CGRect(x: 0.0, y: 37.5, width: 75.0, height: 75.0))
    
    UIColor.red.setFill()
    context.fill(CGRect(x: 75.0, y: 0.0, width: 150.0, height: 150.0))
    
    UIColor.green.setFill()
    context.cgContext.fillEllipse(in:
        CGRect(x: 225.0, y: 37.5, width: 75.0, height: 75.0))
}

/**
 *  代码很简洁，但是不容易维护和扩展
 *  比如需要在中间插入一个新的图形...
 *
 *  下面我们通过 Functional 式封装，使得API 达到灵活、易扩展、易读等特点,
 *  最终效果如下
 
     let blueSquare = square(side: 1).filled(.blue)
     let redSquare = square(side: 2).filled(.red)
     let greenCircle = circle(diameter: 1).filled(.green)
     let example1 = blueSquare ||| redSquare ||| greenCircle
 
 
     let cyanCircle = circle(diameter: 1).filled(.cyan)
     let example2 = blueSquare ||| cyanCircle ||| redSquare ||| greenCircle
 
 */


//MARK: - Functional Style 实现封装

//根据现在的需求定义三种图类型
enum Primitive {
    ///圆形
    case ellipse
    ///方形形
    case rectangle
    ///文字
    case text(String)
}

//定义几种图形组合情况
indirect enum Diagram {
    ///一个可以定义大小的Primitive图形
    case primitive(CGSize, Primitive)
    
    ///左右组合
    case beside(Diagram, Diagram)
    
    ///上下组合
    case below(Diagram, Diagram)
    
    ///给图形填充颜色
    case attributed(Attribute, Diagram)
    
    ///对其位置
    case align(CGPoint, Diagram)
}

//可以扩展为Diagram添加其他属性
enum Attribute {
    case fillColor(UIColor)
}

//MARK: -Calculating

//计算Diagram的宽高
extension Diagram {
    var size: CGSize {
        switch self {
        case .primitive(let size, _):
            return size
        case .attributed(_, let x):
            return x.size
        case let .beside(l, r):
            let sizeL = l.size
            let sizeR = r.size
            //宽度取和，高度取最大的
            return CGSize(width: sizeL.width + sizeR.width,
                          height: max(sizeL.height, sizeR.height))
        case let .below(l, r):
            //高度取和，宽度取最大的
            return CGSize(width: max(l.size.width, r.size.width),
                          height: l.size.height + r.size.height)
        case .align(_, let r):
            return r.size
        }
    }
}

extension CGSize {
    /// 根据给定的size及center，获得在目标区域所占的frame
    /// 原则：在宽高比例一定的情况下，填充原来的区域，在根据center确定位置
    /// - Parameters:
    ///   - rect: 目标区域
    ///   - alignment: 在目标区域的中心点
    /// - Returns: 最终在目标区域中的frame
    func fit(into rect: CGRect, alignment: CGPoint) -> CGRect {
        let scale = min(rect.width / width, rect.height / height)
        let targetSize = scale * self
        let spacerSize = alignment.size * (rect.size - targetSize)
        return CGRect(origin: rect.origin + spacerSize.point, size: targetSize)
    }
}

//MARK: -辅助计算方法
func *(l: CGFloat, r: CGSize) -> CGSize {
    return CGSize(width: l * r.width, height: l * r.height)
}

func *(l: CGSize, r: CGSize) -> CGSize {
    return CGSize(width: l.width * r.width, height: l.height * r.height)
}

func -(l: CGSize, r: CGSize) -> CGSize {
    return CGSize(width: l.width - r.width, height: l.height - r.height)
}

func +(l: CGPoint, r: CGPoint) -> CGPoint {
    return CGPoint(x: l.x + r.x, y: l.y + r.y)
}

extension CGSize {
    var point: CGPoint {
        return CGPoint(x: self.width, y: self.height)
    }
}

extension CGPoint {
    var size: CGSize {
        return CGSize(width: x, height: y)
    }
}

//MARK: - Draw-开始画图

//画基本的Primitive 方法； 圆 方 文字
extension CGContext {
    func draw(_ primitive: Primitive, in frame: CGRect) {
        switch primitive {
        case .rectangle:
            fill(frame)
        case .ellipse:
            fillEllipse(in: frame)
        case .text(let text):
            let font = UIFont.systemFont(ofSize: 12)
            let attributes = [NSAttributedString.Key.font: font]
            let attributedText = NSAttributedString(string: text, attributes: attributes)
            attributedText.draw(in: frame)
        }
    }
}

//画 diagram方法
extension CGContext {
    func draw(_ diagram: Diagram, in bounds: CGRect) {
        switch diagram {
        case let .primitive(size, primitive):
            //根据给定的size，通过fit获得在目标范围内的frame，以center为中心
            let bounds = size.fit(into: bounds, alignment: .center)
            draw(primitive, in: bounds)
            
            //根据给定的对齐，通过fit获得diagram的frame，然后递归调用draw 方法
        case .align(let alignment, let diagram):
            let bounds = diagram.size.fit(into: bounds, alignment: alignment)
            draw(diagram, in: bounds)
            
            //水平方向的组合，将给定的bounds，根据左右两个diagram，进行拆分，然后分别绘制左右diagram
        case let .beside(left, right):
            let (lBounds, rBounds) = bounds.split(
                ratio: left.size.width/diagram.size.width, edge: .minXEdge)
            draw(left, in: lBounds)
            draw(right, in: rBounds)
            
            //上下方向的组合，将给定的bounds，根据上下两个diagram，进行拆分，然后分别绘制左右diagram
        case .below(let top, let bottom):
            let (tBounds, bBounds) = bounds.split(
                ratio: top.size.height/diagram.size.height, edge: .minYEdge)
            draw(top, in: tBounds)
            draw(bottom, in: bBounds)
            
            //保存状态，填充颜色，画图
        case let .attributed(.fillColor(color), diagram):
            saveGState()
            color.set()
            draw(diagram, in: bounds)
            restoreGState()
        }
    }
}


extension CGRect {
    func split(ratio: CGFloat, edge: CGRectEdge) -> (CGRect, CGRect) {
        let length = edge.isHorizontal ? width : height
        return divided(atDistance: length * ratio, from: edge)
    }
}

extension CGRectEdge {
    var isHorizontal: Bool {
        return self == .maxXEdge || self == .minXEdge;
    }
}


extension CGPoint {
    static let bottom = CGPoint(x: 0.5, y: 1)
    static let top = CGPoint(x: 0.5, y: 1)
    static let center = CGPoint(x: 0.5, y: 0.5)
}



//MARK: - Extra Combinators
//将简单功能进行组合，提供更便捷的顶层方法
//这些方法可以放在extension 或者initializers中
func rect(width: CGFloat, height: CGFloat) -> Diagram {
    return .primitive(CGSize(width: width, height: height), .rectangle)
}

func circle(diameter: CGFloat) -> Diagram {
    return .primitive(CGSize(width: diameter, height: diameter), .ellipse)
}

func text(_ theText: String, width: CGFloat, height: CGFloat) -> Diagram {
    return .primitive(CGSize(width: width, height: height), .text(theText))
}

func square(side: CGFloat) -> Diagram {
    return rect(width: side, height: side)
}

extension Diagram {
    func filled(_ color: UIColor) -> Diagram {
        return .attributed(.fillColor(color), self)
    }
    
    func aligned(to position: CGPoint) -> Diagram {
        return .align(position, self)
    }
}

//MARK: -定义operators 使得代码更加易读，更functional
//水平组合运算符
precedencegroup HorizontalCombination {
    higherThan: VerticalCombination
    associativity: left
}
infix operator |||: HorizontalCombination
func |||(l: Diagram, r: Diagram) -> Diagram {
    return .beside(l, r)
}

//垂直组合运算符
precedencegroup VerticalCombination {
    associativity: left
}
infix operator --- : VerticalCombination
func ---(l: Diagram, r: Diagram) -> Diagram {
    return .below(l, r)
}



extension Diagram {
    init() {
        self = rect(width: 0, height: 0)
    }
}

extension Sequence where Iterator.Element == Diagram {
    var hcat: Diagram {
        return reduce(Diagram(), |||)
    }
}


extension Sequence where Iterator.Element == CGFloat {
    var normalized: [CGFloat] {
        let maxVal = reduce(0, Swift.max)
        return map { $0 / maxVal }
    }
}


import PlaygroundSupport

//为了使得自定义类型在Playground中可显示
extension Diagram: CustomPlaygroundDisplayConvertible {
    var playgroundDescription: Any {
        let bounds = CGRect(origin: .zero, size: CGSize(width: 300, height: 200))
        let renderer = UIGraphicsImageRenderer(bounds: bounds)
        return renderer.image {
            $0.cgContext.draw(self, in: bounds)
        }
    }
}

//MARK: - Final
let blueSquare = square(side: 1).filled(.blue)
let redSquare = square(side: 2).filled(.red)
let greenCircle = circle(diameter: 1).filled(.green)
let example1 = blueSquare ||| redSquare ||| greenCircle

let cyanCircle = circle(diameter: 1).filled(.cyan)
let example2 = [blueSquare, cyanCircle, redSquare, greenCircle].hcat


//func barGraph(_ input: [(String, Double)]) -> Diagram {
//    let values: [CGFloat] = input.map { CGFloat($0.1) }
//    let bars = values.normalized.map { x in
//        return rect(width: 1, height: 3 * x).filled(.orange).aligned(to: .bottom)
//        }.hcat
//    let labels = input.map { label, _ in
//        return text(label, width: 1, height: 0.3).aligned(to: .top)
//        }.hcat
//    return bars --- labels
//}
//
//let cities = [
//    "Shanghai": 14.01,
//    "Istanbul": 13.3,
//    "Moscow": 10.56,
//    "New York": 8.33,
//    "Berlin": 3.43
//]
//
//let example3 = barGraph(Array(cities))



let center = CGPoint(x: 0.25, y: 0.5)
let target = CGRect(x: 0, y: 0, width: 200, height: 100)
let result = CGSize(width: 2, height: 0.5).fit(into: target, alignment: center)



